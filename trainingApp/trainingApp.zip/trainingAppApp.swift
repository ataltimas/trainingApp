//
//  trainingAppApp.swift
//  trainingApp
//
//  Created by scholar on 4/16/23.
//

import SwiftUI

@main
struct trainingAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
